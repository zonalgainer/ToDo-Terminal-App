# ToDo Terminal App

A simple Python command-line app for managing a to-do list in the terminal.

## Features

- Add new tasks
- View all tasks
- Delete tasks
- Stores tasks in a local text file

## Usage

```bash
python todo.py add "Buy groceries"
python todo.py list
python todo.py delete 1
```

## Requirements

- Python 3.x
